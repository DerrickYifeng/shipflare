# Handoff: Your AI Team (ShipFlare)

## Overview

"Your AI Team" is a new top-level view in the ShipFlare app (sibling to Today, My Product, Calendar, Growth, Settings). It reframes ShipFlare's agent system as a **team of specialists managed by a Team Lead**. The user chats naturally with the Team Lead; the Lead delegates sub-tasks to 5 specialist agents (Nova, Ember, Sable, Arlo, Kit), and the user can peek into any specialist's live workspace.

The guiding principle: one conversation, transparent delegation, nothing posts without user approval.

## About the Design Files

The files in `design/` are **design references created in HTML/React-via-Babel** — a working prototype that shows intended look, structure, and interaction patterns. **They are not production code.** The task is to **recreate this design in the existing ShipFlare codebase** (Next.js + React, Apple-inspired design system already present — see `colors_and_type.css` and the existing `Today` / `My Product` views) using its established patterns, components, and tokens.

- Reuse the existing `Sidebar`, `TopNav`, `HeaderBar`, `Button`, `Badge`, `Toast` primitives (see `design/shell.jsx` for reference — these already exist in the app).
- Reuse the existing design tokens from `colors_and_type.css` — do **not** introduce new colors, radii, or font stacks.
- Match the spacing, interaction, and visual rhythm of the existing Today view.

## Fidelity

**High-fidelity (hifi)** — pixel-perfect mock with final colors, typography, spacing, and interactions. Recreate accordingly.

## Navigation Integration

Add a new nav item to the `NAV_ITEMS` array in `shell.jsx`:

```js
{ id: 'team', label: 'Your AI Team', icon: 'zap' }
```

Position: between `Growth` and `Settings`. The `zap` icon is already defined in `NavIcon`.

Route: `/team` (or however the app routes views).

## The Screen: `Your AI Team`

### Purpose
User briefs the Team Lead in natural language. Team Lead delegates across 5 specialists. User watches delegation happen, clicks any specialist to see their live workspace, and ultimately approves output that flows back into Today.

### Page-level Layout

The main content area (right of the app Sidebar, below TopNav) contains:

1. **`HeaderBar`** (reuse existing) — title `"Your AI Team"`, meta `"1 Team Lead · 5 specialists · nothing ships without your approval"`.
2. **Status banner** — full-width, tinted blue (`#e8f2fc`).
3. **Three-column grid** filling remaining width:
   - Left rail: **280px** — Team Lead + Specialists + Token budget
   - Center: **flex (min-width: 0)** — conversation + composer
   - Right rail: **380px** — focused Agent Workspace + Today's Output summary
   - Gap: **20px** between columns
   - Page horizontal padding: **24px**
   - Bottom padding: **60px** (so content clears the sticky composer)

4. **Sticky composer** — `position: fixed; bottom: 0`, spans the full width of the main content area (left: 220px to match the app sidebar, right: 0), padding `0 24px 20px`. Inside, uses the **same three-column grid** as the page so the composer sits exactly under the center column.

### Status Banner

- Height: auto · padding `10px 14px` · background `#e8f2fc` · border-radius 10px
- Content row (flex, gap 10): 
  - `LIVE` badge (uppercase mono, 11px, weight 600, color `#0066cc`)
  - 1px × 12px divider `rgba(0,102,204,0.3)`
  - `Team Lead is active.` — color `#1d1d1f`, 13px
  - `3 drafts in flight · 2 in review · 3 approved & ready.` — color `rgba(0,0,0,0.56)`
  - spacer
  - `RUN-8421-03 · started 9:02 AM` (mono 11px, color `rgba(0,0,0,0.48)`)

### Left Rail — Team Lead + Specialists + Token Budget

**Outer container:** sticky (`top: 72px`), background `#f5f5f7`, border-radius 12, padding 10px, max-height `calc(100vh - 88px)`, flex column. Inner scroll area takes `flex:1, overflow-y:auto`.

**Section headers** (uppercase mono 10px, weight 600, `#1d1d1f` left, `rgba(0,0,0,0.48)` right meta):
- `TEAM LEAD` · right meta `3 PARALLEL`
- `SPECIALISTS` · right meta `5 SEATS`

**Agent Row** (`<button>`, full width, text-align left, border-radius 10, padding `10px 12px`, margin-bottom 4):
- Active state: background `#fff`, `box-shadow: 0 0 0 1px rgba(0,113,227,0.3), 0 1px 2px rgba(0,0,0,0.04)`
- Inactive: transparent, no shadow
- Transition: `all 200ms cubic-bezier(.16,1,.3,1)`

Row header (flex, gap 10):
- **AgentDot** — 28×28 circle, background = agent.color, white initial letter (`fontSize: size*0.5; fontWeight: 600`)
- Middle column (flex 1, min-width 0):
  - Name — 13px, weight 500, `#1d1d1f`, letter-spacing -0.16
  - Status dot — 5px circle, color per agent status (pulses 1200ms on `working`/`thinking`/`active`)
  - `CODE` — 10px mono, `rgba(0,0,0,0.48)`, uppercase, margin-top 1
- Task count pill (when `taskCount > 0`):
  - min-width 20, height 20, padding `0 6px`, border-radius 5, font 11/600 mono
  - Active: `#1d1d1f` bg, `#fff` fg. Inactive: `rgba(0,0,0,0.06)` bg, `rgba(0,0,0,0.64)` fg.

Agent notes (when present): vertical stack, gap 3, padding-left 38 (aligns under name):
- Row: flex gap 6, 11px text, `rgba(0,0,0,0.56)`, letter-spacing -0.08, line-height 1.4
- Bullet: 3×3 circle in agent.color
- Text: truncate (`overflow:hidden; text-overflow:ellipsis; white-space:nowrap`)

**Token Budget** (pinned to bottom of the rail):
- Margin-top 10, padding `12px 12px 10px`, background `#fff`, border-radius 10, shadow `0 1px 2px rgba(0,0,0,0.03)`
- Header row: `TOKEN BUDGET` (mono 10/600 uppercase) left, `18,420 / 40,000` right (mono 11px; denominator `rgba(0,0,0,0.48)`)
- Bar: height 5, background `#ebebed`, border-radius 999, flex row. Each segment is a div with its agent color and `width: ${pct}%`.
- Legend: flex wrap, gap `4px 10px`, margin-top 8. Each: 6×6 rounded-2 swatch + uppercase mono 10px label in `rgba(0,0,0,0.56)`.

### Center Column — Conversation + Composer

**Section header** (above messages, margin-bottom 14):
- `CONVERSATION` (mono 11, uppercase, `rgba(0,0,0,0.48)`)
- horizontal hairline `rgba(0,0,0,0.06)` (flex:1)
- Right meta: `Team Lead · {N} turns` (mono 11, tabular-nums)

**UserMessage** (right-aligned, max-width 78%):
- Background `#0071e3`, color `#fff`, padding `10px 14px`, border-radius 14
- Font 14, letter-spacing -0.224, line-height 1.47
- Shadow: `0 1px 2px rgba(0,0,0,0.06)`
- Margin-bottom 14

**LeadMessage** (left-aligned):
- Flex row gap 10, animation `sfFadeIn 240ms cubic-bezier(.16,1,.3,1)`, margin-bottom 14
- AgentDot: 28×28, color `#1d1d1f`, initial `L`
- Body column:
  - Header row: name `Team Lead` (13/500), timestamp (mono 11, `rgba(0,0,0,0.48)`)
  - Body: 14/1.5, `#1d1d1f`, letter-spacing -0.224
  - Optional embedded **DelegationCard** (below)

**DelegationCard** (appears inline in a LeadMessage when the Lead dispatches work):
- Margin-top 8, background `#f5f5f7`, border-radius 12, padding 12
- Header: `DISPATCHED` (mono 11, uppercase, left), hairline, `{N} tasks` (mono 11, right)
- Body: flex column, gap 6. Each row is a `<button>`:
  - Padding `8px 10px`, border-radius 8, flex row gap 10
  - Active state (when activeAgentId === task.agent.id): background `#fff`, shadow `0 0 0 1px rgba(0,113,227,0.2), 0 1px 2px rgba(0,0,0,0.04)`
  - Inactive: transparent
  - Children: AgentDot (18, agent color), label (13/16, `#1d1d1f`), status chip on right:
    - `done`: `#248a3d`, shows `✓ {elapsed}`
    - `working`: `{agent.color}`, shows `{progress}%`
    - `queued`: `rgba(0,0,0,0.48)`, shows `queued`

Working task progress bumps by +3% every 800ms until reaching 100 (simulation on a `setInterval` inside the view).

**Spacer** at the end of messages: `height: 140` so the last message isn't hidden under the sticky composer.

**Sticky Claude-style Composer** (position: fixed, pinned to viewport bottom):
- Wrapper: `position: fixed; left: 220 (app sidebar width); right: 0; bottom: 0; padding: 0 24px 20px; z-index: 20; pointer-events: none`
- Inside, three-column grid (same as page) — composer sits in center cell, left/right cells empty
- Inner composer cell has `pointer-events: auto` and `position: relative`

Composer card:
- `background: #fff; border-radius: 20; border: 1px solid rgba(0,0,0,0.08); padding: 14px 14px 10px`
- `box-shadow: 0 4px 12px rgba(0,0,0,0.04), 0 20px 40px rgba(0,0,0,0.08)`
- Above the card: 40px fade mask from `rgba(255,255,255,1)` at bottom to `rgba(255,255,255,0)` at top (so scrolled messages fade into composer)

Textarea:
- `width: 100%; border: none; outline: none; resize: none; background: transparent`
- `font-size: 15; letter-spacing: -0.224; color: #1d1d1f; line-height: 1.5`
- `padding: 4px 4px 6px; min-height: 28; max-height: 200`
- Auto-grows on input (`element.style.height = 'auto'; element.style.height = Math.min(200, scrollHeight)+'px'`)
- Placeholder: `"Brief your Team Lead…"` in `rgba(0,0,0,0.32)`
- **Enter** submits, **Shift+Enter** newline.

Footer row (flex gap 4, margin-top 4):
- Left: attach button (32×32 circle, transparent, `rgba(0,0,0,0.56)`) — SVG plus (`M8 3v10M3 8h10`)
- Spacer
- Send button (32×32 circle):
  - Enabled: `#1d1d1f` bg, `#fff` fg
  - Disabled (empty draft): `rgba(0,0,0,0.08)` bg, `rgba(0,0,0,0.32)` fg
  - SVG up-arrow: `M8 13V3M4 7l4-4 4 4`

Below composer (center-aligned, margin-top 6, 11px, `rgba(0,0,0,0.4)`):
`"Team Lead routes your brief across 5 specialists · nothing posts without your approval"`

**On send** (`Enter` or click):
1. Append `{kind:'user', text}` to thread
2. Append `{kind:'lead', body: <Team Lead ack with delegation>, delegation: […]}` — delegation kicks off with Nova `working 8%` + Ember `queued`

### Right Rail — Agent Workspace + Today's Output

Outer: sticky (`top: 72`).

**AgentWorkspace** (if an agent is open, else empty-state card):
- Card: background `#fff`, border-radius 12, shadow `0 3px 5px rgba(0,0,0,0.04), 0 6px 20px rgba(0,0,0,0.06)`, overflow hidden, animation `sfFadeIn 240ms`
- **Header** (flex row, padding `12px 16px`, border-bottom `1px solid rgba(0,0,0,0.06)`, background `linear-gradient(180deg, {agent.color}08 0%, #fff 100%)`):
  - AgentDot 24
  - Name (15/500) + role (mono 11 uppercase, `rgba(0,0,0,0.48)`)
  - Subtitle line (12, `rgba(0,0,0,0.56)`)
  - Close × button (right, `rgba(0,0,0,0.48)`, 16px, clears activeId)
- **Body** (padding 16): agent-specific content (see below)

**Empty state**: padding 20, background `#f5f5f7`, border-radius 12, center-aligned, 13px, `rgba(0,0,0,0.48)`. Copy: `"Select an agent on the left to open their workspace."`

**Today's Output card** (always visible below the workspace):
- Margin-top 14, padding 14, background `#f5f5f7`, border-radius 12
- Header: `TODAY'S OUTPUT` (mono 10/600 uppercase, `rgba(0,0,0,0.48)`, margin-bottom 10)
- 2×2 grid gap 10:
  - `3 · Replies ready`
  - `2 · Posts scheduled`
  - `27 · Threads scanned`
  - `0.94 · Voice match`
- Each cell: big value (mono 20/500), label (11, `rgba(0,0,0,0.48)`, letter-spacing -0.08, margin-top 1)

### Agent Workspace Bodies

#### Nova (Discovery) — `#5e5ce6`
Subtitle: `"Scoring threads from 5 communities against the 0.65 relevance gate."`

Header row: `CANDIDATE THREADS` left (mono 11 uppercase) + hairline + `3 kept / 1 dropped · gate 0.65` right.

Thread list (flex column gap 6). Each thread is a vertical card (padding `10px 12px`, border-radius 8, background `#f5f5f7` when kept else transparent, opacity 0.55 when dropped):
- Top row (flex, gap 8): source label (mono 10 uppercase `rgba(0,0,0,0.48)`) · spacer · score (mono 12, `#248a3d` if kept else `#d70015`, weight 600, 2 decimals)
- Title (13/1.35, `#1d1d1f`, wraps naturally — **do not truncate**)
- Signal (11, `rgba(0,0,0,0.48)`) — e.g., `"Opinion thread · 142↑ · 38💬"`

Sample threads:
1. `r/ExperiencedDevs` · "Hot take: modern PM tools over-engineer for PMs" · 0.86 · kept
2. `r/SaaS` · "Stack check: what's everyone running for roadmap?" · 0.72 · kept
3. `𝕏` · "@jaylinwrites: anyone moved off Jira recently?" · 0.81 · kept
4. `r/startups` · "Review: I used 6 PM tools in 3 months" · 0.41 · dropped

#### Ember (Drafting) — `#ff9500`
Subtitle: `"Writing in your voice. Three drafts per thread, best one promoted."`

Header: `DRAFT · R/EXPERIENCEDDEVS REPLY` + hairline + `v3` right.

Draft body (padding 12, background `#f5f5f7`, border-radius 8, font 14/1.5, `#1d1d1f`). Sample:
> "This is basically why Linear exists — it's built IC-first. My PM tried to add custom workflows and I just… ignored them. Status hasn't changed."

Check chips row (flex wrap, gap 8):
- Each chip: padding `4px 8px`, border-radius 6
- Pass: background `#eef9f1`, color `#248a3d`
- Fail: background `#fff0ef`, color `#d70015`
- Chip content: 5px bullet + label + mono value
- Sample: `Voice match 0.94` · `FTC safe clean` · `Length 161 chars` · `Brand bleed subtle`

Actions row (flex gap 8):
- Primary: `Send to Today` — height 32, padding `0 12px`, border-radius 8, bg `#0071e3`, white
- Secondary: `Revise` — bg `rgba(0,0,0,0.05)`, `#1d1d1f`
- Ghost: `See v1 · v2` — transparent, `rgba(0,0,0,0.56)`

#### Sable (Review) — `#248a3d`
Subtitle: `"Voice match, FTC, subreddit rules, competitor mentions."`

Check list (flex column gap 6). Each row (padding `10px 12px`, border-radius 8, background `#f5f5f7`):
- 18×18 circle icon: `#eef9f1`/`#248a3d` for pass with `✓`, `#fff8eb`/`#c67a05` for review with `!`
- Label (13, `#1d1d1f`) + note (mono 11, `rgba(0,0,0,0.48)`)

Items:
1. "Voice drift (sounds like you in last 30 posts)" · pass · `cosine 0.94`
2. "FTC disclosure (unpaid, not a customer endorsement)" · pass · `no risk terms`
3. "Subreddit rules (r/ExperiencedDevs — no self-promo)" · pass · `subtle, relevant`
4. "Competitor mention policy" · review · `mentions "Jira" — OK, OP named it first`

#### Arlo (Posting) — `#0071e3`
Subtitle: `"Waits for your approval, then posts. Never touches send without you."`

Intro line (13, `rgba(0,0,0,0.56)`): `"Waiting on your approval. Nothing posts without it."`

Then a mono info block (padding 12, border-radius 8, background `#f5f5f7`, mono 12, `rgba(0,0,0,0.64)`, line-height 1.6):
```
LAST POST · r/startups · 4h ago · 2.2k imp · 31↑ · 6💬
NEXT QUEUE · 3 drafts approved, ready to post
COOLDOWN · 12m until next r/ExperiencedDevs post is eligible
```

#### Kit (Scheduling) — `#af52de`
Subtitle: `"Picks time slots based on community rhythm and your cooldowns."`

Schedule list (flex column gap 4). Each row is a 3-col grid (`100px 1fr auto`, padding `10px 12px`, border-radius 8):
- Time (mono 12, `rgba(0,0,0,0.64)`, tabular-nums)
- Label (13, `#1d1d1f`)
- State (mono 11 uppercase): `posted` → `#248a3d`, `ready` → `#0071e3`, `scheduled` → `rgba(0,0,0,0.48)`
- Background `#f5f5f7` except `posted` which is transparent + opacity 0.5

Items:
1. `9:14 AM` · "r/ExperiencedDevs reply" · posted
2. `11:30 AM` · "𝕏 reply to @jaylinwrites" · ready
3. `2:00 PM` · "𝕏 original post · Educational" · ready
4. `4:30 PM` · "𝕏 original post · Metric" · scheduled
5. `Tomorrow 10:00` · "r/SaaS stack check reply" · scheduled

## Interactions & Behavior

### Sending a message
- `Enter` sends · `Shift+Enter` newline
- Textarea auto-grows between 28px and 200px
- On send: append user bubble → append lead ack with delegation card (Nova working, Ember queued) → clear draft

### Delegation progress simulation
- On mount, start a `setInterval(800ms)` that increments any delegation task where `status === 'working' && progress < 100` by `+3`, capping at 100.
- In production, this should come from a real agent-state subscription (WebSocket / SSE / polling).

### Opening an agent
- Click any row in the Left Rail **or** any task inside a DelegationCard → set `activeId` to that agent's id → right rail shows that agent's workspace.
- Active agent gets a blue focus ring in the left rail and in the delegation card.
- × button in the workspace header clears activeId → empty-state card.

### Status pulse
- Specialist status dots pulse (animation `sfPulse 1200ms ease-in-out infinite`) when status ∈ `{thinking, working, active}`.

## State

```ts
type Agent = {
  id: 'lead' | 'nova' | 'ember' | 'sable' | 'arlo' | 'kit';
  name: string;
  code: string;               // uppercase role label
  kind: 'lead' | 'specialist';
  initial: string;            // single letter
  color: string;              // hex
  status: 'idle' | 'thinking' | 'working' | 'active' | 'done';
  taskCount: number;
  notes: string[];
  workspaceSubtitle: string;
};

type DelegationTask = {
  id: string;
  agent: Agent;
  label: string;
  status: 'queued' | 'working' | 'done';
  elapsed: string | null;     // "12s" when done
  progress: number;           // 0-100
};

type Message =
  | { kind: 'user'; text: string }
  | { kind: 'lead'; timestamp: string; body: ReactNode; delegation?: DelegationTask[] };

// View state
const [thread, setThread] = useState<Message[]>(INITIAL_THREAD);
const [activeId, setActiveId] = useState<string | null>('nova');
const [draft, setDraft] = useState('');
```

Seed data (Agents, Tokens, initial thread) is in `design/index.html` under the main `<script type="text/babel">` tag.

## Design Tokens

All tokens come from the existing ShipFlare system (see `design/colors_and_type.css`). **Do not introduce new ones.**

### Colors used on this screen
| Token | Hex | Usage |
|---|---|---|
| `--sf-bg-primary` | `#f5f5f7` | Left rail, inset cards, message surfaces |
| `--sf-bg-secondary` | `#ffffff` | Cards, workspace, composer |
| `--sf-bg-tertiary` | `#ebebed` | Progress track |
| `--sf-fg-1` | `#1d1d1f` | Primary text, send button, lead avatar |
| `--sf-fg-3` | `rgba(0,0,0,0.56)` | Secondary text |
| `--sf-fg-4` | `rgba(0,0,0,0.48)` | Mono meta |
| `--sf-border` | `rgba(0,0,0,0.08)` | Composer border |
| `--sf-border-subtle` | `rgba(0,0,0,0.04)` | Hairlines |
| `--sf-accent` | `#0071e3` | User bubbles, active focus ring, Arlo |
| `--sf-accent-light` | `#e8f2fc` | Status banner |
| `--sf-success-ink` | `#248a3d` | Pass chips, done states |
| `--sf-success-light` | `#eef9f1` | Pass chip bg |
| `--sf-warning-ink` | `#c67a05` | Review chips |
| `--sf-warning-light` | `#fff8eb` | Review chip bg |
| `--sf-error-ink` | `#d70015` | Fail score, dropped |
| `--sf-error-light` | `#fff0ef` | Fail chip bg |

### Agent colors (new — add to tokens if desired)
| Agent | Hex | Role |
|---|---|---|
| Team Lead | `#1d1d1f` | Orchestrator (reuses `--sf-fg-1`) |
| Nova | `#5e5ce6` | Discovery (iOS indigo) |
| Ember | `#ff9500` | Drafting (iOS orange) |
| Sable | `#248a3d` | Review (reuses `--sf-success-ink`) |
| Arlo | `#0071e3` | Posting (reuses `--sf-accent`) |
| Kit | `#af52de` | Scheduling (iOS purple) |

### Typography
All from existing system. Sizes used:
- 28/600 letter-spacing 0.196 — HeaderBar title
- 15/500 — Workspace name, composer input
- 14/400 letter-spacing -0.224 — body text, message bubbles
- 13/500 letter-spacing -0.16 — row names, task labels
- 13/400 — inline meta
- 12/500 `--sf-font-mono` uppercase letter-spacing -0.12 — `CONVERSATION`, `DISPATCHED`, etc.
- 11/600 mono uppercase — section headers
- 11/500 mono — status chips, meta counters
- 10/400 mono uppercase — agent code labels

### Spacing
8px base — use `--sf-space-*` tokens. Key values: 4, 8, 10, 12, 14, 16, 20, 24.

### Radius
- Composer: 20 (custom for this surface)
- Cards, workspace, left rail: 12 (`--sf-radius-xl`)
- Rows, inset cards: 8 (`--sf-radius-md`)
- Badges, chips: 5–6
- Message bubbles: 14
- AgentDot, status dot, send button: 50%

### Shadow
- Cards: `0 3px 5px rgba(0,0,0,0.04), 0 6px 20px rgba(0,0,0,0.06)` (`--sf-shadow-card`)
- Composer: `0 4px 12px rgba(0,0,0,0.04), 0 20px 40px rgba(0,0,0,0.08)` (slightly stronger, floating)
- Focus ring: `0 0 0 1px rgba(0,113,227,0.3), 0 1px 2px rgba(0,0,0,0.04)`

### Motion
- Primary easing: `cubic-bezier(0.16, 1, 0.3, 1)` (`--sf-ease`)
- Durations: `200ms` transitions, `240ms` fade-in, `1200ms` pulse loop
- Prefers-reduced-motion: disable all animations (already handled in existing CSS)

## Assets

- `logo-128.png` — existing ShipFlare logo, reuse from current assets.
- No new icons required — attach button is inline SVG (plus symbol), send is inline SVG (up-arrow). Status dots, bullets, agent initials are geometry, not icons.
- No external imagery.

## Files in `design/`

- `index.html` — full working prototype. **Read first.** The main `<script type="text/babel">` block contains the `App`, `AITeamView`, `LeftRail`, agent seed data, and the sticky composer.
- `ai_team.jsx` — all agent-workspace components (`SpecialistCard`, `UserMessage`, `LeadMessage`, `DelegationCard`, `AgentWorkspace`, `NovaWorkspace`, `EmberWorkspace`, `SableWorkspace`, `ArloWorkspace`, `KitWorkspace`, `AgentDot`).
- `shell.jsx` — existing app primitives (`Sidebar`, `TopNav`, `HeaderBar`, `Button`, `Badge`, `Toast`, `NavIcon`). For reference only — these already exist in the codebase.
- `today.jsx` — existing Today view primitives (`ReplyCard`, `PostCard`, etc.). For reference — shows the visual rhythm and component patterns the new view should match.
- `colors_and_type.css` — existing design token file. For reference — do not duplicate.

## Implementation checklist

- [ ] Add `team` nav item to `NAV_ITEMS` with `zap` icon
- [ ] Route for the new view
- [ ] Extract `AgentDot`, `SpecialistCard`/`AgentRow`, `UserMessage`, `LeadMessage`, `DelegationCard`, `AgentWorkspace` into the app's component structure
- [ ] Build `LeftRail`, `Composer` as screen-local components
- [ ] Wire agent-state to real backend (replace the `setInterval` progress sim)
- [ ] Connect "Send to Today" action in Ember workspace to the existing Today approve flow
- [ ] Reduced-motion already handled by existing CSS; verify nothing new breaks it
- [ ] Verify sticky composer alignment on narrow viewports (may need to collapse right rail at smaller widths)
