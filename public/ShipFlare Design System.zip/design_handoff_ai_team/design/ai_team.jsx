// Your AI Team — chat with Team Lead, see specialist agents, open a focused workspace
const { useState: useStateT, useEffect: useEffectT, useRef: useRefT, useMemo: useMemoT } = React;

/* ─── Agent avatar (monogram disc with agent color) ──── */
function AgentDot({ color, initial, size = 20, active }) {
  return (
    <span style={{
      display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
      width: size, height: size, borderRadius: '50%',
      background: color, color: '#fff',
      fontSize: size * 0.5, fontWeight: 600, letterSpacing: '-0.12px',
      fontFamily: 'var(--sf-font-text)',
      boxShadow: active ? `0 0 0 3px ${color}33` : 'none',
      flexShrink: 0,
    }}>{initial}</span>
  );
}

/* ─── Specialist card (sidebar right-rail) ─────────────── */
function SpecialistCard({ agent, open, onOpen }) {
  const statusColor = {
    idle: 'rgba(0,0,0,0.24)',
    thinking: agent.color,
    working: agent.color,
    done: '#248a3d',
  }[agent.status] || 'rgba(0,0,0,0.24)';

  return (
    <button onClick={onOpen} style={{
      display: 'block', textAlign: 'left', width: '100%',
      background: '#fff',
      border: 'none',
      borderRadius: 12, padding: 14,
      boxShadow: open
        ? '0 0 0 2px #0071e3, 0 3px 5px rgba(0,0,0,0.04), 0 6px 20px rgba(0,0,0,0.06)'
        : '0 3px 5px rgba(0,0,0,0.04), 0 6px 20px rgba(0,0,0,0.06)',
      cursor: 'pointer', fontFamily: 'inherit',
      transition: 'all 200ms cubic-bezier(.16,1,.3,1)',
    }}>
      <div style={{ display: 'flex', alignItems: 'flex-start', gap: 10 }}>
        <AgentDot color={agent.color} initial={agent.initial} size={28} />
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
            <span style={{ fontSize: 14, fontWeight: 500, color: '#1d1d1f', letterSpacing: '-0.224px' }}>{agent.name}</span>
            <span style={{ width: 6, height: 6, borderRadius: '50%', background: statusColor,
              animation: (agent.status === 'thinking' || agent.status === 'working') ? 'sfPulse 1200ms ease-in-out infinite' : 'none' }} />
          </div>
          <div style={{ fontSize: 12, color: 'rgba(0,0,0,0.48)', letterSpacing: '-0.12px', marginTop: 1 }}>{agent.role}</div>
        </div>
        <span style={{ fontFamily: 'var(--sf-font-mono)', fontSize: 11, letterSpacing: '-0.08px',
          textTransform: 'uppercase', color: 'rgba(0,0,0,0.48)', fontVariantNumeric: 'tabular-nums' }}>
          {agent.queue > 0 ? `${agent.queue} in queue` : 'idle'}
        </span>
      </div>
      {agent.currentTask && (
        <div style={{ marginTop: 10, padding: '8px 10px', background: '#f5f5f7', borderRadius: 8,
          fontSize: 12, color: 'rgba(0,0,0,0.64)', letterSpacing: '-0.12px', lineHeight: 1.4 }}>
          {agent.currentTask}
        </div>
      )}
    </button>
  );
}

/* ─── Chat message bubbles ─────────────────────────────── */
function UserMessage({ text }) {
  return (
    <div style={{ display: 'flex', justifyContent: 'flex-end', marginBottom: 14 }}>
      <div style={{
        maxWidth: '78%',
        background: '#0071e3', color: '#fff',
        padding: '10px 14px', borderRadius: 14,
        fontSize: 14, letterSpacing: '-0.224px', lineHeight: 1.47,
        boxShadow: '0 1px 2px rgba(0,0,0,0.06)',
      }}>{text}</div>
    </div>
  );
}

function LeadMessage({ children, timestamp }) {
  return (
    <div style={{ display: 'flex', gap: 10, marginBottom: 14, animation: 'sfFadeIn 240ms cubic-bezier(.16,1,.3,1)' }}>
      <AgentDot color="#1d1d1f" initial="L" size={28} />
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ display: 'flex', alignItems: 'baseline', gap: 8, marginBottom: 4 }}>
          <span style={{ fontSize: 13, fontWeight: 500, color: '#1d1d1f', letterSpacing: '-0.16px' }}>Team Lead</span>
          {timestamp && <span style={{ fontFamily: 'var(--sf-font-mono)', fontSize: 11, color: 'rgba(0,0,0,0.48)', letterSpacing: '-0.08px' }}>{timestamp}</span>}
        </div>
        <div style={{ fontSize: 14, color: '#1d1d1f', letterSpacing: '-0.224px', lineHeight: 1.5 }}>{children}</div>
      </div>
    </div>
  );
}

/* ─── Delegation summary card — appears inline in chat ─ */
function DelegationCard({ lead, items, onOpenAgent, activeAgentId }) {
  return (
    <div style={{
      marginTop: 8,
      background: '#f5f5f7', borderRadius: 12,
      padding: 12,
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 10 }}>
        <span style={{ fontFamily: 'var(--sf-font-mono)', fontSize: 11, letterSpacing: '-0.08px',
          textTransform: 'uppercase', color: 'rgba(0,0,0,0.48)' }}>Dispatched</span>
        <span style={{ flex: 1, height: 1, background: 'rgba(0,0,0,0.06)' }} />
        <span style={{ fontFamily: 'var(--sf-font-mono)', fontSize: 11, color: 'rgba(0,0,0,0.48)',
          fontVariantNumeric: 'tabular-nums' }}>{items.length} tasks</span>
      </div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
        {items.map(t => {
          const active = t.agent.id === activeAgentId;
          return (
            <button key={t.id} onClick={() => onOpenAgent(t.agent.id)} style={{
              display: 'flex', alignItems: 'center', gap: 10,
              padding: '8px 10px',
              background: active ? '#fff' : 'transparent',
              border: 'none', borderRadius: 8,
              cursor: 'pointer', textAlign: 'left', fontFamily: 'inherit',
              boxShadow: active ? '0 0 0 1px rgba(0,113,227,0.2), 0 1px 2px rgba(0,0,0,0.04)' : 'none',
              transition: 'all 150ms',
            }}>
              <AgentDot color={t.agent.color} initial={t.agent.initial} size={18} />
              <span style={{ fontSize: 13, color: '#1d1d1f', letterSpacing: '-0.16px', flex: 1 }}>{t.label}</span>
              <span style={{
                fontFamily: 'var(--sf-font-mono)', fontSize: 11, letterSpacing: '-0.08px',
                textTransform: 'uppercase', fontVariantNumeric: 'tabular-nums',
                color: t.status === 'done' ? '#248a3d'
                     : t.status === 'working' ? t.agent.color
                     : 'rgba(0,0,0,0.48)',
              }}>
                {t.status === 'done' ? `✓ ${t.elapsed}` : t.status === 'working' ? `${t.progress}%` : 'queued'}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
}

/* ─── Focused agent workspace — inline after a chat block ─ */
function AgentWorkspace({ agent, onClose }) {
  if (!agent) return null;
  return (
    <div style={{
      marginBottom: 20,
      background: '#fff', borderRadius: 12,
      boxShadow: '0 3px 5px rgba(0,0,0,0.04), 0 6px 20px rgba(0,0,0,0.06)',
      overflow: 'hidden',
      animation: 'sfFadeIn 240ms cubic-bezier(.16,1,.3,1)',
    }}>
      {/* Header */}
      <div style={{
        display: 'flex', alignItems: 'center', gap: 10,
        padding: '12px 16px',
        borderBottom: '1px solid rgba(0,0,0,0.06)',
        background: `linear-gradient(180deg, ${agent.color}08 0%, #fff 100%)`,
      }}>
        <AgentDot color={agent.color} initial={agent.initial} size={24} />
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <span style={{ fontSize: 15, fontWeight: 500, color: '#1d1d1f', letterSpacing: '-0.224px' }}>{agent.name}</span>
            <span style={{ fontFamily: 'var(--sf-font-mono)', fontSize: 11, letterSpacing: '-0.08px',
              textTransform: 'uppercase', color: 'rgba(0,0,0,0.48)' }}>{agent.role}</span>
          </div>
          <div style={{ fontSize: 12, color: 'rgba(0,0,0,0.56)', letterSpacing: '-0.12px', marginTop: 1 }}>
            {agent.workspaceSubtitle}
          </div>
        </div>
        <button onClick={onClose} style={{
          background: 'transparent', border: 'none', cursor: 'pointer', padding: 6,
          borderRadius: 6, color: 'rgba(0,0,0,0.48)', fontSize: 16, lineHeight: 1,
        }}>×</button>
      </div>

      {/* Body — agent-specific */}
      <div style={{ padding: 16 }}>
        {agent.id === 'nova' && <NovaWorkspace />}
        {agent.id === 'ember' && <EmberWorkspace />}
        {agent.id === 'sable' && <SableWorkspace />}
        {agent.id === 'arlo' && <ArloWorkspace />}
        {agent.id === 'kit' && <KitWorkspace />}
      </div>
    </div>
  );
}

/* ─── Agent-specific workspace bodies ──────────────────── */
function NovaWorkspace() {
  const threads = [
    { src: 'r/ExperiencedDevs', title: "Hot take: modern PM tools over-engineer for PMs", score: 0.86, signal: 'Opinion thread · 142↑ · 38💬', kept: true },
    { src: 'r/SaaS', title: "Stack check: what's everyone running for roadmap?", score: 0.72, signal: 'Stack check · 81↑ · 22💬', kept: true },
    { src: '𝕏', title: "@jaylinwrites: anyone moved off Jira recently?", score: 0.81, signal: 'Venting · 14💬 · <15m old', kept: true },
    { src: 'r/startups', title: "Review: I used 6 PM tools in 3 months", score: 0.41, signal: 'Review post · 4↑', kept: false },
  ];
  return (
    <div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 10,
        fontFamily: 'var(--sf-font-mono)', fontSize: 11, letterSpacing: '-0.08px',
        textTransform: 'uppercase', color: 'rgba(0,0,0,0.48)' }}>
        <span>Candidate threads</span>
        <span style={{ flex: 1, height: 1, background: 'rgba(0,0,0,0.06)' }} />
        <span style={{ fontVariantNumeric: 'tabular-nums' }}>3 kept / 1 dropped · gate 0.65</span>
      </div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
        {threads.map((t, i) => (
          <div key={i} style={{
            display: 'flex', flexDirection: 'column', gap: 4,
            padding: '10px 12px', borderRadius: 8,
            background: t.kept ? '#f5f5f7' : 'transparent',
            opacity: t.kept ? 1 : 0.55,
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <span style={{ fontFamily: 'var(--sf-font-mono)', fontSize: 10, letterSpacing: '-0.08px',
                color: 'rgba(0,0,0,0.48)', textTransform: 'uppercase', fontWeight: 500 }}>{t.src}</span>
              <span style={{ flex: 1 }} />
              <span style={{ fontFamily: 'var(--sf-font-mono)', fontSize: 12, fontVariantNumeric: 'tabular-nums',
                color: t.kept ? '#248a3d' : '#d70015', fontWeight: 600 }}>{t.score.toFixed(2)}</span>
            </div>
            <div style={{ fontSize: 13, color: '#1d1d1f', letterSpacing: '-0.16px', lineHeight: 1.35 }}>{t.title}</div>
            <div style={{ fontSize: 11, color: 'rgba(0,0,0,0.48)', letterSpacing: '-0.08px' }}>{t.signal}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

function EmberWorkspace() {
  return (
    <div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 10,
        fontFamily: 'var(--sf-font-mono)', fontSize: 11, letterSpacing: '-0.08px',
        textTransform: 'uppercase', color: 'rgba(0,0,0,0.48)' }}>
        <span>Draft · r/ExperiencedDevs reply</span>
        <span style={{ flex: 1, height: 1, background: 'rgba(0,0,0,0.06)' }} />
        <span style={{ fontVariantNumeric: 'tabular-nums' }}>v3</span>
      </div>
      <div style={{ padding: 12, background: '#f5f5f7', borderRadius: 8, marginBottom: 10,
        fontSize: 14, color: '#1d1d1f', letterSpacing: '-0.224px', lineHeight: 1.5 }}>
        This is basically why Linear exists — it's built IC-first. My PM tried to add custom workflows and I just… ignored them. Status hasn't changed.
      </div>
      <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginBottom: 12 }}>
        {[
          { k: 'Voice match', v: '0.94', ok: true },
          { k: 'FTC safe', v: 'clean', ok: true },
          { k: 'Length', v: '161 chars', ok: true },
          { k: 'Brand bleed', v: 'subtle', ok: true },
        ].map(c => (
          <span key={c.k} style={{
            display: 'inline-flex', alignItems: 'center', gap: 6,
            padding: '4px 8px', borderRadius: 6,
            background: c.ok ? '#eef9f1' : '#fff0ef',
            color: c.ok ? '#248a3d' : '#d70015',
            fontSize: 11, letterSpacing: '-0.08px', fontWeight: 500,
          }}>
            <span style={{ width: 5, height: 5, borderRadius: '50%', background: 'currentColor' }} />
            {c.k} <span style={{ fontFamily: 'var(--sf-font-mono)', fontVariantNumeric: 'tabular-nums' }}>{c.v}</span>
          </span>
        ))}
      </div>
      <div style={{ display: 'flex', gap: 8 }}>
        <button style={{
          height: 32, padding: '0 12px', borderRadius: 8, border: 'none',
          background: '#0071e3', color: '#fff', fontSize: 13, fontWeight: 500,
          letterSpacing: '-0.16px', cursor: 'pointer', fontFamily: 'inherit',
        }}>Send to Today</button>
        <button style={{
          height: 32, padding: '0 12px', borderRadius: 8, border: 'none',
          background: 'rgba(0,0,0,0.05)', color: '#1d1d1f', fontSize: 13, fontWeight: 500,
          letterSpacing: '-0.16px', cursor: 'pointer', fontFamily: 'inherit',
        }}>Revise</button>
        <button style={{
          height: 32, padding: '0 12px', borderRadius: 8, border: 'none',
          background: 'transparent', color: 'rgba(0,0,0,0.56)', fontSize: 13,
          letterSpacing: '-0.16px', cursor: 'pointer', fontFamily: 'inherit',
        }}>See v1 · v2</button>
      </div>
    </div>
  );
}

function SableWorkspace() {
  const checks = [
    { label: 'Voice drift (sounds like you in last 30 posts)', value: 'pass', note: 'cosine 0.94' },
    { label: 'FTC disclosure (unpaid, not a customer endorsement)', value: 'pass', note: 'no risk terms' },
    { label: 'Subreddit rules (r/ExperiencedDevs — no self-promo)', value: 'pass', note: 'subtle, relevant' },
    { label: 'Competitor mention policy', value: 'review', note: 'mentions "Jira" — OK, OP named it first' },
  ];
  return (
    <div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
        {checks.map((c, i) => {
          const ok = c.value === 'pass';
          return (
            <div key={i} style={{
              display: 'flex', alignItems: 'center', gap: 10,
              padding: '10px 12px', borderRadius: 8, background: '#f5f5f7',
            }}>
              <span style={{
                width: 18, height: 18, borderRadius: '50%',
                background: ok ? '#eef9f1' : '#fff8eb',
                color: ok ? '#248a3d' : '#c67a05',
                display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
                fontSize: 11, fontWeight: 600, flexShrink: 0,
              }}>{ok ? '✓' : '!'}</span>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontSize: 13, color: '#1d1d1f', letterSpacing: '-0.16px' }}>{c.label}</div>
                <div style={{ fontFamily: 'var(--sf-font-mono)', fontSize: 11, color: 'rgba(0,0,0,0.48)', letterSpacing: '-0.08px', marginTop: 1 }}>{c.note}</div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

function ArloWorkspace() {
  return (
    <div>
      <div style={{ fontSize: 13, color: 'rgba(0,0,0,0.56)', letterSpacing: '-0.16px', marginBottom: 10 }}>
        Waiting on your approval. Nothing posts without it.
      </div>
      <div style={{ padding: 12, borderRadius: 8, background: '#f5f5f7', fontFamily: 'var(--sf-font-mono)',
        fontSize: 12, color: 'rgba(0,0,0,0.64)', letterSpacing: '-0.12px', lineHeight: 1.6 }}>
        <div>LAST POST · r/startups · 4h ago · 2.2k imp · 31↑ · 6💬</div>
        <div>NEXT QUEUE · 3 drafts approved, ready to post</div>
        <div>COOLDOWN · 12m until next r/ExperiencedDevs post is eligible</div>
      </div>
    </div>
  );
}

function KitWorkspace() {
  const slots = [
    { time: '9:14 AM', label: 'r/ExperiencedDevs reply', state: 'posted' },
    { time: '11:30 AM', label: '𝕏 reply to @jaylinwrites', state: 'ready' },
    { time: '2:00 PM', label: '𝕏 original post · Educational', state: 'ready' },
    { time: '4:30 PM', label: '𝕏 original post · Metric', state: 'scheduled' },
    { time: 'Tomorrow 10:00', label: 'r/SaaS stack check reply', state: 'scheduled' },
  ];
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
      {slots.map((s, i) => (
        <div key={i} style={{
          display: 'grid', gridTemplateColumns: '100px 1fr auto', gap: 12, alignItems: 'center',
          padding: '10px 12px', borderRadius: 8,
          background: s.state === 'posted' ? 'transparent' : '#f5f5f7',
          opacity: s.state === 'posted' ? 0.5 : 1,
        }}>
          <span style={{ fontFamily: 'var(--sf-font-mono)', fontSize: 12, color: 'rgba(0,0,0,0.64)',
            fontVariantNumeric: 'tabular-nums', letterSpacing: '-0.12px' }}>{s.time}</span>
          <span style={{ fontSize: 13, color: '#1d1d1f', letterSpacing: '-0.16px' }}>{s.label}</span>
          <span style={{ fontFamily: 'var(--sf-font-mono)', fontSize: 11, letterSpacing: '-0.08px',
            textTransform: 'uppercase',
            color: s.state === 'posted' ? '#248a3d' : s.state === 'ready' ? '#0071e3' : 'rgba(0,0,0,0.48)' }}>
            {s.state === 'posted' ? '✓ posted' : s.state}
          </span>
        </div>
      ))}
    </div>
  );
}

Object.assign(window, {
  AgentDot, SpecialistCard, UserMessage, LeadMessage, DelegationCard, AgentWorkspace,
});
