// ShipFlare app shell — sidebar, top nav, header bar
const { useState } = React;

const NAV_ITEMS = [
  { id: 'today', label: 'Today', icon: 'today' },
  { id: 'product', label: 'My Product', icon: 'product' },
  { id: 'calendar', label: 'Calendar', icon: 'cal' },
  { id: 'growth', label: 'Growth', icon: 'growth' },
  { id: 'team', label: 'Your AI Team', icon: 'zap' },
  { id: 'settings', label: 'Settings', icon: 'gear' },
];

function NavIcon({ kind }) {
  const s = { width: 16, height: 16, fill: 'none', stroke: 'currentColor', strokeWidth: 1.5 };
  if (kind === 'today') return <svg {...s} viewBox="0 0 16 16"><circle cx="8" cy="8" r="6"/><path d="M8 4v4l2.5 1.5"/></svg>;
  if (kind === 'product') return <svg {...s} viewBox="0 0 16 16"><path d="M2 5l6-3 6 3-6 3-6-3z"/><path d="M2 5v6l6 3V8"/><path d="M14 5v6l-6 3"/></svg>;
  if (kind === 'growth') return <svg {...s} viewBox="0 0 16 16"><path d="M1 14l4-5 3 3 7-9"/><path d="M11 3h4v4"/></svg>;
  if (kind === 'cal') return <svg {...s} viewBox="0 0 16 16"><rect x="2" y="3" width="12" height="12" rx="1"/><path d="M11 1v4M5 1v4M2 7h12"/></svg>;
  if (kind === 'zap') return <svg {...s} viewBox="0 0 16 16"><path d="M9 1L3 9h5l-1 6 6-8H8l1-6z"/></svg>;
  if (kind === 'chart') return <svg {...s} viewBox="0 0 16 16"><path d="M2 13h12"/><path d="M4 11V8M8 11V5M12 11V3"/></svg>;
  if (kind === 'gear') return <svg {...s} viewBox="0 0 16 16"><circle cx="8" cy="8" r="2.5"/><path d="M8 1v2M8 13v2M1 8h2M13 8h2M2.8 2.8l1.4 1.4M11.8 11.8l1.4 1.4M2.8 13.2l1.4-1.4M11.8 4.2l1.4-1.4"/></svg>;
  return null;
}

function Sidebar({ active, onSelect }) {
  return (
    <aside style={{
      width: 220, flexShrink: 0,
      background: 'rgba(0,0,0,0.03)', backdropFilter: 'blur(20px)',
      borderRight: '1px solid rgba(0,0,0,0.08)',
      padding: '14px 12px',
      display: 'flex', flexDirection: 'column',
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '0 8px', height: 44 }}>
        <img src="assets/logo-128.png" width="22" height="22" alt="" />
        <span style={{ fontSize: 17, fontWeight: 600, letterSpacing: '-0.374px', color: '#1d1d1f' }}>ShipFlare</span>
      </div>
      <nav style={{ marginTop: 12, display: 'flex', flexDirection: 'column', gap: 2 }}>
        {NAV_ITEMS.map(item => {
          const isActive = active === item.id;
          return (
            <a key={item.id} onClick={() => onSelect(item.id)} style={{
              display: 'flex', alignItems: 'center', gap: 10,
              height: 36, padding: '0 10px',
              borderRadius: 8, cursor: 'pointer',
              fontSize: 14, letterSpacing: '-0.224px',
              background: isActive ? '#0071e3' : 'transparent',
              color: isActive ? '#fff' : 'rgba(0,0,0,0.64)',
              fontWeight: isActive ? 500 : 400,
              transition: 'all 200ms cubic-bezier(.16,1,.3,1)',
            }}>
              <NavIcon kind={item.icon} />
              {item.label}
            </a>
          );
        })}
      </nav>
      <div style={{ marginTop: 'auto', padding: 8, display: 'flex', alignItems: 'center', gap: 10 }}>
        <div style={{ width: 28, height: 28, borderRadius: '50%', background: 'linear-gradient(135deg, #0071e3, #1d1d1f)', color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 12, fontWeight: 600 }}>DY</div>
        <div style={{ minWidth: 0, flex: 1 }}>
          <div style={{ fontSize: 12, fontWeight: 500, color: '#1d1d1f', letterSpacing: '-0.12px' }}>Derrick Yifeng</div>
          <div style={{ fontSize: 11, color: 'rgba(0,0,0,0.48)', letterSpacing: '-0.08px', fontFamily: 'var(--sf-font-mono)' }}>Linear.app</div>
        </div>
      </div>
    </aside>
  );
}

function TopNav({ title, rightSlot }) {
  return (
    <div style={{
      height: 56, borderBottom: '1px solid rgba(0,0,0,0.06)',
      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      padding: '0 24px',
      background: 'rgba(255,255,255,0.72)',
      backdropFilter: 'saturate(180%) blur(20px)',
      WebkitBackdropFilter: 'saturate(180%) blur(20px)',
      position: 'sticky', top: 0, zIndex: 10,
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 10, fontFamily: 'var(--sf-font-mono)', fontSize: 12, letterSpacing: '-0.08px', textTransform: 'uppercase', color: 'rgba(0,0,0,0.48)' }}>
        <span>{title}</span>
      </div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>{rightSlot}</div>
    </div>
  );
}

function HeaderBar({ title, meta }) {
  return (
    <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', padding: '28px 24px 16px' }}>
      <div>
        <h1 style={{ margin: 0, fontSize: 28, fontWeight: 600, letterSpacing: '0.196px', lineHeight: 1.14, color: '#1d1d1f' }}>{title}</h1>
        {meta && <p style={{ margin: '6px 0 0', fontSize: 14, color: 'rgba(0,0,0,0.48)', letterSpacing: '-0.224px' }}>{meta}</p>}
      </div>
    </div>
  );
}

function Button({ variant = 'primary', onClick, disabled, children }) {
  const base = {
    display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: 6,
    height: 36, padding: '0 14px',
    borderRadius: 8, border: 'none', cursor: 'pointer',
    fontSize: 14, letterSpacing: '-0.224px', fontFamily: 'inherit',
    transition: 'all 200ms cubic-bezier(.16,1,.3,1)',
    opacity: disabled ? 0.4 : 1, pointerEvents: disabled ? 'none' : 'auto',
  };
  const variants = {
    primary: { background: '#0071e3', color: '#fff' },
    secondary: { background: 'rgba(0,0,0,0.05)', color: '#1d1d1f' },
    ghost: { background: 'transparent', color: 'rgba(0,0,0,0.64)' },
    danger: { background: '#ff3b30', color: '#fff' },
  };
  return <button onClick={onClick} disabled={disabled} style={{ ...base, ...variants[variant] }}>{children}</button>;
}

function Badge({ variant = 'default', mono, children }) {
  const variants = {
    default: { bg: 'rgba(0,0,0,0.05)', fg: 'rgba(0,0,0,0.56)' },
    accent: { bg: '#e8f2fc', fg: '#0071e3' },
    success: { bg: '#eef9f1', fg: '#248a3d' },
    warning: { bg: '#fff8eb', fg: '#c67a05' },
    error: { bg: '#fff0ef', fg: '#d70015' },
  };
  const v = variants[variant];
  return (
    <span style={{
      display: 'inline-flex', alignItems: 'center',
      height: 22, padding: '0 8px',
      borderRadius: 5, background: v.bg, color: v.fg,
      fontSize: 12, fontWeight: 500, letterSpacing: '-0.12px',
      fontFamily: mono ? 'var(--sf-font-mono)' : 'inherit',
      fontVariantNumeric: mono ? 'tabular-nums' : 'normal',
    }}>{children}</span>
  );
}

function Toast({ message, variant = 'info', onDismiss }) {
  if (!message) return null;
  const fg = variant === 'error' ? '#d70015' : variant === 'warning' ? '#c67a05' : '#1d1d1f';
  return (
    <div style={{
      position: 'fixed', bottom: 24, left: '50%', transform: 'translateX(-50%)',
      zIndex: 200,
      background: '#fff', borderRadius: 12,
      padding: '12px 16px',
      boxShadow: '0 3px 5px rgba(0,0,0,0.06), 0 10px 30px rgba(0,0,0,0.12)',
      display: 'flex', alignItems: 'center', gap: 10,
      fontSize: 14, letterSpacing: '-0.224px', color: fg,
      animation: 'sfToast 240ms cubic-bezier(.16,1,.3,1)',
    }}>
      <span>{message}</span>
      <button onClick={onDismiss} style={{ background: 'none', border: 'none', color: 'rgba(0,0,0,0.48)', cursor: 'pointer', padding: 4, fontSize: 16 }}>×</button>
      <style>{`@keyframes sfToast { from { transform: translate(-50%, 12px); opacity: 0 } to { transform: translate(-50%, 0); opacity: 1 } }`}</style>
    </div>
  );
}

Object.assign(window, { Sidebar, TopNav, HeaderBar, Button, Badge, Toast, NavIcon });
