// ShipFlare app — Today view cards (reply-card, post-card, scan-header, source chips, agent card)
const { useState: useStateA, useEffect: useEffectA } = React;

/* ─── Source chip ────────────────────────────────────────── */
function SourceChip({ source, state, count, active, onClick }) {
  const styles = {
    queued: { bg: '#f5f5f7', fg: 'rgba(0,0,0,0.48)' },
    searching: { bg: '#f5f5f7', fg: 'rgba(0,0,0,0.64)' },
    searched: { bg: '#eef9f1', fg: '#248a3d' },
    failed: { bg: '#fff0ef', fg: '#d70015' },
  };
  const s = styles[state] || styles.queued;
  return (
    <button onClick={onClick} style={{
      display: 'inline-flex', alignItems: 'center', gap: 6,
      padding: '6px 10px', borderRadius: 980,
      border: 'none', cursor: 'pointer', fontFamily: 'inherit',
      background: s.bg, color: s.fg,
      fontSize: 12, fontWeight: 500, letterSpacing: '-0.12px',
      boxShadow: active ? '0 0 0 2px #0071e3' : 'none',
      transition: 'all 200ms',
    }}>
      {state === 'searching' && <span style={{ width: 6, height: 6, borderRadius: '50%', background: '#0071e3', animation: 'sfPulse 1200ms ease-in-out infinite' }} />}
      {source}
      {state === 'searched' && <span style={{ fontFamily: 'var(--sf-font-mono)', fontVariantNumeric: 'tabular-nums', marginLeft: 2 }}>{count}</span>}
      {state === 'failed' && <span style={{ marginLeft: 2 }}>· failed</span>}
    </button>
  );
}

/* ─── Scan header ────────────────────────────────────────── */
function ReplyScanHeader({ lastScannedAt, replyCount, scanning, onScan }) {
  return (
    <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: 16, marginBottom: 20 }}>
      <div style={{ minWidth: 0 }}>
        <h3 style={{ margin: 0, fontSize: 17, fontWeight: 500, letterSpacing: '-0.374px', color: '#1d1d1f' }}>Replies</h3>
        <p style={{ margin: '4px 0 0', fontSize: 14, color: 'rgba(0,0,0,0.48)', letterSpacing: '-0.224px' }}>
          Last scan: {lastScannedAt}{replyCount > 0 && ` · ${replyCount} replies generated`}
        </p>
      </div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
        <Badge variant="default">Auto-scans every 4h</Badge>
        <Button variant="secondary" onClick={onScan} disabled={scanning}>
          {scanning ? 'Scanning…' : 'Scan for replies'}
        </Button>
      </div>
    </div>
  );
}

/* ─── Original content embed (shown above a reply) ──────── */
function OriginalContentEmbed({ author, body, platform, postedAt, upvotes, commentCount }) {
  return (
    <div style={{
      padding: 12, borderRadius: 8,
      border: '1px solid rgba(0,0,0,0.06)',
      background: '#fff',
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 6, fontSize: 12, letterSpacing: '-0.12px', color: 'rgba(0,0,0,0.48)' }}>
        <span style={{ fontFamily: 'var(--sf-font-mono)', textTransform: 'uppercase' }}>{platform === 'x' ? '𝕏' : platform}</span>
        <span>·</span>
        <span style={{ fontWeight: 500, color: '#1d1d1f' }}>{author}</span>
        <span>·</span>
        <span>{postedAt}</span>
        {upvotes && <><span>·</span><span>↑ {upvotes}</span></>}
        {commentCount && <><span>·</span><span>💬 {commentCount}</span></>}
      </div>
      <p style={{ margin: 0, fontSize: 14, color: '#1d1d1f', letterSpacing: '-0.224px', lineHeight: 1.5 }}>{body}</p>
    </div>
  );
}

/* ─── Toggle row (expandable reasoning) ──────────────────── */
function Toggle({ label, children }) {
  const [open, setOpen] = useStateA(false);
  return (
    <div>
      <button onClick={() => setOpen(o => !o)} style={{
        display: 'inline-flex', alignItems: 'center', gap: 6,
        background: 'none', border: 'none', cursor: 'pointer',
        padding: 0, fontFamily: 'inherit',
        color: 'rgba(0,0,0,0.56)', fontSize: 13, letterSpacing: '-0.16px',
      }}>
        <svg width="10" height="10" viewBox="0 0 12 12" style={{ transform: open ? 'rotate(90deg)' : 'rotate(0)', transition: 'transform 200ms' }}>
          <path d="M4 2l4 4-4 4" fill="none" stroke="currentColor" strokeWidth="1.5"/>
        </svg>
        {label}
      </button>
      {open && <div style={{ marginTop: 8, paddingLeft: 16 }}>{children}</div>}
    </div>
  );
}

/* ─── Reply card ─────────────────────────────────────────── */
function ReplyCard({ item, onApprove, onSkip, onEdit, active }) {
  const [editing, setEditing] = useStateA(false);
  const [editBody, setEditBody] = useStateA(item.draftBody);
  const cap = item.platform === 'x' ? 240 : 10_000;
  const activeBody = editing ? editBody : item.draftBody;
  const len = activeBody.length;
  const over = Math.max(0, len - cap);
  const warn = len > cap - 20;

  const borderMap = {
    time_sensitive: 'border-left: 4px solid #ff3b30;',
    scheduled: 'border-left: 4px solid #0071e3;',
    optional: '',
  };

  return (
    <div style={{
      borderRadius: 12, padding: 16,
      background: '#fff',
      boxShadow: '0 3px 5px rgba(0,0,0,0.04), 0 6px 20px rgba(0,0,0,0.06)',
      borderLeft: item.priority === 'time_sensitive' ? '4px solid #ff3b30' : item.priority === 'scheduled' ? '4px solid #0071e3' : 'none',
      boxSizing: 'border-box',
      outline: active ? '2px solid #0071e3' : 'none',
      animation: 'sfFadeIn 240ms cubic-bezier(.16,1,.3,1)',
    }}>
      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: 12, marginBottom: 12 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, flexWrap: 'wrap' }}>
          <span style={{ fontFamily: 'var(--sf-font-mono)', fontSize: 11, letterSpacing: '-0.08px', textTransform: 'uppercase', color: 'rgba(0,0,0,0.48)' }}>
            {item.platform === 'x' ? '𝕏' : item.platform}
          </span>
          <Badge variant="accent">{item.community}</Badge>
          <span style={{ fontFamily: 'var(--sf-font-mono)', fontSize: 11, letterSpacing: '-0.08px', textTransform: 'uppercase', color: 'rgba(0,0,0,0.48)' }}>reply</span>
          <Badge variant={item.confidence >= 0.7 ? 'success' : 'default'} mono>{Math.round(item.confidence * 100)}%</Badge>
        </div>
        {item.priority === 'time_sensitive' && (
          <span style={{ display: 'inline-block', width: 8, height: 8, borderRadius: '50%', background: '#ff3b30', animation: 'sfPulse 1200ms ease-in-out infinite' }} />
        )}
      </div>

      {/* Original thread */}
      <div style={{ marginBottom: 12 }}>
        <OriginalContentEmbed {...item.thread} platform={item.platform} />
      </div>

      {/* Reply */}
      {!editing && (
        <div style={{ padding: 12, borderRadius: 8, background: '#f5f5f7', marginBottom: 12 }}>
          <div style={{ fontFamily: 'var(--sf-font-mono)', fontSize: 11, letterSpacing: '-0.08px', textTransform: 'uppercase', fontWeight: 500, color: 'rgba(0,0,0,0.48)', marginBottom: 6 }}>Your reply</div>
          <p style={{ margin: 0, fontSize: 14, color: '#1d1d1f', letterSpacing: '-0.224px', lineHeight: 1.5, whiteSpace: 'pre-wrap' }}>{item.draftBody}</p>
          <p style={{ margin: '8px 0 0', fontFamily: 'var(--sf-font-mono)', fontSize: 12, letterSpacing: '-0.12px', fontVariantNumeric: 'tabular-nums',
            color: over > 0 ? '#d70015' : warn ? '#c67a05' : 'rgba(0,0,0,0.48)' }}>
            {len}/{cap}
          </p>
        </div>
      )}

      {editing && (
        <div style={{ marginBottom: 12 }}>
          <textarea value={editBody} onChange={e => setEditBody(e.target.value)} rows={4}
            style={{
              width: '100%', background: '#f5f5f7',
              border: '1px solid rgba(0,0,0,0.08)', borderRadius: 8,
              padding: 12, fontSize: 14, letterSpacing: '-0.224px',
              color: '#1d1d1f', lineHeight: 1.5, resize: 'vertical',
              minHeight: 80, fontFamily: 'inherit', outline: 'none',
              boxSizing: 'border-box',
            }}
            onFocus={e => e.currentTarget.style.boxShadow = '0 0 0 3px rgba(0,113,227,0.15)'}
            onBlur={e => e.currentTarget.style.boxShadow = 'none'}
          />
          <p style={{ margin: '6px 0 0', fontFamily: 'var(--sf-font-mono)', fontSize: 12, letterSpacing: '-0.12px',
            color: over > 0 ? '#d70015' : warn ? '#c67a05' : 'rgba(0,0,0,0.48)' }}>
            {len}/{cap}
          </p>
          <div style={{ display: 'flex', gap: 8, marginTop: 8 }}>
            <Button onClick={() => { onEdit(item.id, editBody); setEditing(false); }}>Save</Button>
            <Button variant="ghost" onClick={() => { setEditBody(item.draftBody); setEditing(false); }}>Cancel</Button>
          </div>
        </div>
      )}

      {/* Why this works */}
      {!editing && item.whyItWorks && (
        <div style={{ marginBottom: 12 }}>
          <Toggle label="Why this works">
            <p style={{ margin: 0, fontSize: 14, color: 'rgba(0,0,0,0.56)', letterSpacing: '-0.224px', lineHeight: 1.5 }}>{item.whyItWorks}</p>
          </Toggle>
        </div>
      )}

      {/* Actions */}
      {!editing && (
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <Button onClick={() => onApprove(item.id)} disabled={over > 0}>Send</Button>
          <Button variant="ghost" onClick={() => setEditing(true)}>Edit</Button>
          <Button variant="ghost" onClick={() => onSkip(item.id)}>Skip</Button>
        </div>
      )}
    </div>
  );
}

/* ─── Post card (simpler — for scheduled original posts) ─ */
function PostCard({ item, onApprove, onSkip }) {
  return (
    <div style={{
      borderRadius: 12, padding: 16, background: '#fff',
      boxShadow: '0 3px 5px rgba(0,0,0,0.04), 0 6px 20px rgba(0,0,0,0.06)',
      borderLeft: item.priority === 'scheduled' ? '4px solid #0071e3' : 'none',
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 12, flexWrap: 'wrap' }}>
        <span style={{ fontFamily: 'var(--sf-font-mono)', fontSize: 11, letterSpacing: '-0.08px', textTransform: 'uppercase', color: 'rgba(0,0,0,0.48)' }}>
          {item.platform === 'x' ? '𝕏' : item.platform}
        </span>
        <span style={{ fontFamily: 'var(--sf-font-mono)', fontSize: 11, letterSpacing: '-0.08px', textTransform: 'uppercase', color: 'rgba(0,0,0,0.48)' }}>{item.contentType}</span>
        <span style={{ fontFamily: 'var(--sf-font-mono)', fontSize: 11, letterSpacing: '-0.08px', color: 'rgba(0,0,0,0.48)' }}>{item.scheduledAt}</span>
      </div>
      <div style={{ padding: 12, borderRadius: 8, background: '#f5f5f7', marginBottom: 12 }}>
        <p style={{ margin: 0, fontSize: 14, color: '#1d1d1f', letterSpacing: '-0.224px', lineHeight: 1.5, whiteSpace: 'pre-wrap' }}>{item.body}</p>
        <p style={{ margin: '8px 0 0', fontFamily: 'var(--sf-font-mono)', fontSize: 12, color: 'rgba(0,0,0,0.48)', fontVariantNumeric: 'tabular-nums' }}>{item.body.length}/280</p>
      </div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
        <Button onClick={() => onApprove(item.id)}>Approve</Button>
        <Button variant="ghost">Edit</Button>
        <Button variant="ghost" onClick={() => onSkip(item.id)}>Skip</Button>
        <Button variant="ghost">Tomorrow</Button>
      </div>
    </div>
  );
}

/* ─── Agent card (war room) ──────────────────────────────── */
function AgentCard({ name, status, detail, progress, stats, cost, elapsed }) {
  const colors = {
    idle: '#8e8e93', active: '#0071e3', complete: '#248a3d', error: '#ff3b30',
  };
  return (
    <div style={{
      background: '#fff', borderRadius: 12, padding: 16,
      boxShadow: '0 3px 5px rgba(0,0,0,0.04), 0 6px 20px rgba(0,0,0,0.06)',
      borderLeft: status === 'active' ? `2px solid ${colors[status]}` : '2px solid transparent',
    }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 8 }}>
        <span style={{ fontFamily: 'var(--sf-font-mono)', fontSize: 11, letterSpacing: '-0.08px', textTransform: 'uppercase', fontWeight: 500, color: '#1d1d1f' }}>{name}</span>
        <span style={{ width: 8, height: 8, borderRadius: '50%', background: colors[status], animation: status === 'active' ? 'sfPulse 1200ms ease-in-out infinite' : 'none' }} />
      </div>
      {detail && <div style={{ fontSize: 13, color: 'rgba(0,0,0,0.56)', letterSpacing: '-0.16px', marginBottom: 10, lineHeight: 1.4 }}>{detail}</div>}
      {progress != null && (
        <div style={{ height: 2, background: '#ebebed', borderRadius: 999, overflow: 'hidden', marginBottom: 10 }}>
          <div style={{ width: `${progress * 100}%`, height: '100%', background: colors[status], transition: 'width 300ms' }} />
        </div>
      )}
      {stats && (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 8 }}>
          {stats.map((s, i) => (
            <div key={i}>
              <div style={{ fontFamily: 'var(--sf-font-mono)', fontSize: 18, fontWeight: 500, color: '#1d1d1f', fontVariantNumeric: 'tabular-nums' }}>{s.value}</div>
              <div style={{ fontFamily: 'var(--sf-font-mono)', fontSize: 10, letterSpacing: '-0.08px', textTransform: 'uppercase', color: 'rgba(0,0,0,0.48)', fontWeight: 500 }}>{s.label}</div>
            </div>
          ))}
        </div>
      )}
      {(cost || elapsed) && (
        <div style={{ marginTop: 10, fontFamily: 'var(--sf-font-mono)', fontSize: 11, letterSpacing: '-0.08px', color: 'rgba(0,0,0,0.48)' }}>
          {cost && `$${cost}`}{cost && elapsed && ' / '}{elapsed && `${elapsed}s`}
        </div>
      )}
    </div>
  );
}

Object.assign(window, { SourceChip, ReplyScanHeader, OriginalContentEmbed, Toggle, ReplyCard, PostCard, AgentCard });
